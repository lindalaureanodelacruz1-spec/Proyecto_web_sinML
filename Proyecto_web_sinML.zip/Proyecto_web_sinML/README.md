# Proyecto_web_sinML

Página web Campus Senati — sitio estático hecho con HTML, CSS y JavaScript puro.

## Páginas
- `index.html` – Inicio (portada, estadísticas, beneficios, noticias)
- `carreras.html` – Lista de carreras con filtro por categoría
- `admision.html` – Pasos, requisitos y preguntas frecuentes
- `contacto.html` – Formulario con validación

## Estructura
```
Proyecto_web_sinML/
├── index.html
├── carreras.html
├── admision.html
├── contacto.html
├── css/
│   └── styles.css
├── js/
│   └── main.js
└── img/
```

## Cómo verlo
Abre `index.html` en tu navegador, o actívalo con GitHub Pages:
**Settings → Pages → Branch: main → Save**.
