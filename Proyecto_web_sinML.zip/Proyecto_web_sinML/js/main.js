// ===== Año actual en el footer =====
document.querySelectorAll("#year").forEach(el => el.textContent = new Date().getFullYear());

// ===== Menú móvil =====
const toggle = document.querySelector(".menu-toggle");
const links = document.querySelector(".nav-links");
if (toggle && links) {
  toggle.addEventListener("click", () => links.classList.toggle("show"));
}

// ===== Contadores animados (inicio) =====
const counters = document.querySelectorAll(".stat-num");
if (counters.length) {
  const animar = (el) => {
    const meta = +el.dataset.target;
    let actual = 0;
    const paso = Math.max(1, Math.ceil(meta / 60));
    const timer = setInterval(() => {
      actual += paso;
      if (actual >= meta) { actual = meta; clearInterval(timer); }
      el.textContent = actual;
    }, 25);
  };
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { animar(e.target); obs.unobserve(e.target); }
    });
  }, { threshold: 0.5 });
  counters.forEach(c => obs.observe(c));
}

// ===== Filtro de carreras =====
const filtros = document.querySelectorAll(".filter-btn");
filtros.forEach(btn => {
  btn.addEventListener("click", () => {
    filtros.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    const cat = btn.dataset.filter;
    document.querySelectorAll(".career").forEach(card => {
      card.classList.toggle("hidden", cat !== "todas" && card.dataset.cat !== cat);
    });
  });
});

// ===== Preguntas frecuentes (acordeón) =====
document.querySelectorAll(".faq-q").forEach(q => {
  q.addEventListener("click", () => {
    const resp = q.nextElementSibling;
    const abierto = q.classList.toggle("open");
    resp.style.maxHeight = abierto ? resp.scrollHeight + "px" : null;
  });
});

// ===== Validación del formulario de contacto =====
const form = document.getElementById("form-contacto");
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const msg = document.getElementById("form-msg");
    const nombre = form.nombre.value.trim();
    const correo = form.correo.value.trim();
    const carrera = form.carrera.value;
    const mensaje = form.mensaje.value.trim();
    const correoValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo);

    if (!nombre || !correo || !carrera || !mensaje) {
      msg.textContent = "Por favor, completa todos los campos.";
      msg.className = "form-msg error";
    } else if (!correoValido) {
      msg.textContent = "Ingresa un correo electrónico válido.";
      msg.className = "form-msg error";
    } else {
      msg.textContent = `¡Gracias, ${nombre}! Tu mensaje fue registrado.`;
      msg.className = "form-msg ok";
      form.reset();
    }
  });
}

// ===== Login demo (solo valida en el navegador, no envía nada) =====
const formLogin = document.getElementById("form-login");
if (formLogin) {
  formLogin.addEventListener("submit", (e) => {
    e.preventDefault();
    const msg = document.getElementById("login-msg");
    const usuario = formLogin.usuario.value.trim();
    const clave = formLogin.clave.value.trim();

    if (!usuario || !clave) {
      msg.textContent = "Ingresa tu usuario y contraseña.";
      msg.className = "form-msg error";
      return;
    }
    // Credenciales de demostración
    if (usuario === "alumno" && clave === "1234") {
      msg.textContent = "¡Bienvenido! Entrando al aula...";
      msg.className = "form-msg ok";
      setTimeout(() => (window.location.href = "aula.html"), 700);
    } else {
      msg.textContent = "Usuario o contraseña incorrectos (usa alumno / 1234).";
      msg.className = "form-msg error";
    }
  });
}

// ===== Menú lateral del aula (móvil) =====
const appToggle = document.querySelector(".app-top .menu-toggle");
const sidebar = document.querySelector(".sidebar");
if (appToggle && sidebar) {
  appToggle.addEventListener("click", () => sidebar.classList.toggle("show"));
}
